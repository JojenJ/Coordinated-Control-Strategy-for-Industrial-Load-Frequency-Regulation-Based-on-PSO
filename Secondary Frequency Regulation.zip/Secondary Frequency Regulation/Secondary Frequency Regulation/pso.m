% 初始化
num_particles = 15; % 粒子数量
max_iter = 30; % 迭代次数
c1 = 1; % 学习因子1
c2 = 1; % 学习因子2
w = 0.7; % 惯性权重
bounds = [0.2, 1.5]; % 解空间范围

% 初始化粒子位置和速度
particles_position = bounds(1) + (bounds(2) - bounds(1)) * rand(num_particles, 2);
particles_velocity = rand(num_particles, 2);

% 初始化个体最佳位置和适应度
personal_best_position = particles_position;
personal_best_fitness = calculate_ITAE(particles_position);

% 初始化全局最佳位置和适应度
[global_best_fitness, idx] = min(personal_best_fitness);
global_best_position = personal_best_position(idx, :);

fitness = zeros(max_iter, 1);

% 迭代
for iter = 1:max_iter
    % 更新粒子速度和位置
    particles_velocity = w * particles_velocity ...
        + c1 * rand(num_particles, 2) .* (personal_best_position - particles_position) ...
        + c2 * rand(num_particles, 2) .* (global_best_position - particles_position);
    particles_position = particles_position + particles_velocity;
    
    % 更新个体最佳位置和适应度
    current_fitness = calculate_ITAE(particles_position);
    update_idx = current_fitness < personal_best_fitness;
    personal_best_position(update_idx, :) = particles_position(update_idx, :);
    personal_best_fitness(update_idx) = current_fitness(update_idx);
    
    % 更新全局最佳位置和适应度
    [current_best_fitness, idx] = min(personal_best_fitness);
    if current_best_fitness < global_best_fitness
        global_best_fitness = current_best_fitness;
        global_best_position = personal_best_position(idx, :);
        global_best_position(global_best_position <= 0) = bounds(1); % 设置为解空间的最小值
    end
    
    fitness(iter) = global_best_fitness;
    % 显示每次迭代的最优适应度  
    fprintf('Iteration %d: Best Fitness = %.4f\n', iter, global_best_fitness);
end

% 显示结果
fprintf('Optimal Solution:\n');
fprintf('kp = %.4f, ki = %.4f\n', global_best_position(1), global_best_position(2));
fprintf('Minimum Value = %.4f\n', global_best_fitness);

figure(1)
iter1 = [1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;17;18;19;20;21;22;23;24;25;26;27;28;29;30];
plot(iter1,fitness,'-r');
legend('协调控制策略');
xlabel('迭代次数');
ylabel('适应度值');
% 
set(0,'ShowHiddenHandles','on'); 
set(gcf,'menubar','figure');

