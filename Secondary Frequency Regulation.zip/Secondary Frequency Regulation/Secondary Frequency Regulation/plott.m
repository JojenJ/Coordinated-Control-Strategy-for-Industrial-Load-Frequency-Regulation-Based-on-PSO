figure(1)
hold on  % 启用图层叠加模式

% 独立绘制每条曲线，分别指定属性
p1 = plot(out.simout.time, out.simout.signals.values,...
    'Color', [0 0.4 0],...        % 深绿色
    'LineStyle', '-',...          % 实线
    'LineWidth', 2.5);            % 线宽微调

% p2 = plot(out.simout1.time, out.simout1.signals.values,...
%     'Color', [0.8 0.2 0.6],...    % 品红色
%     'LineStyle', '--',...         % 长虚线
%     'LineWidth', 2,... 
%     'Marker', 'o',...             % 添加圆形标记
%     'MarkerIndices', 1:50:length(out.simout1.time)); % 标记间隔
% 
% p3 = plot(out.simout2.time, out.simout2.signals.values,...
%     'Color', [0 0.6 0.8],...      % 青蓝色
%     'LineStyle', ':',...          % 点线
%     'LineWidth', 2.2,... 
%     'Marker', '^',...             % 三角标记
%     'MarkerIndices', 10:40:length(out.simout2.time));

p4 = plot(out.simout3.time, out.simout3.signals.values,...
    'Color', [0.9 0.5 0],...      % 橙色
    'LineStyle', '-.',...         % 点划线
    'LineWidth', 2,... 
    'Marker', 's',...             % 方块标记
    'MarkerIndices', 20:60:length(out.simout3.time));

hold off
grid on

% % 专业级图例设置
% legend([p1 p2 p3 p4],...
%     {'LFC', 'LFC+电热锅炉', 'LFC+电解铝', '协调控制策略'},...
%     'FontSize', 10,...            % 字体大小
%     'Location', 'best',...        % 自动选择最佳位置
%     'Box', 'off');                % 去除图例边框
% 
% xlabel('Time/seconds', 'FontWeight', 'bold');
% ylabel('f/Hz', 'FontWeight', 'bold');
% 
% % 设置坐标轴粗细
% ax = gca;
% ax.Box = 'on';                    % 开启全边框
% ax.BoxStyle = 'full';             % 全包围模式
% ax.LineWidth = 1.2;               % 坐标轴线宽
% ax.FontSize = 11;                 % 刻度标签字号
% ax.XGrid = 'on';                  % X方向网格
% ax.YGrid = 'on';                  % Y方向网格
% ax.GridLineStyle = '--';          % 网格线型
% ax.GridAlpha = 0.3;               % 网格透明度


legend([p1 p4],...
    {'LFC', '协调控制策略'},...
    'FontSize', 10,...            % 字体大小
    'Location', 'best',...        % 自动选择最佳位置
    'Box', 'off');                % 去除图例边框

xlabel('Time/seconds', 'FontWeight', 'bold');
ylabel('f/Hz', 'FontWeight', 'bold');

% 设置坐标轴粗细
ax = gca;
ax.Box = 'on';                    % 开启全边框
ax.BoxStyle = 'full';             % 全包围模式
ax.LineWidth = 1.2;               % 坐标轴线宽
ax.FontSize = 11;                 % 刻度标签字号
ax.XGrid = 'on';                  % X方向网格
ax.YGrid = 'on';                  % Y方向网格
ax.GridLineStyle = '--';          % 网格线型
ax.GridAlpha = 0.3;               % 网格透明度