function itae = calculate_ITAE(K_matrix)
    % 获取参数组合的数量
    num_combinations = size(K_matrix, 1);
    
    % 初始化性能指标矩阵
    itae = zeros(num_combinations, 1);
    
    % 循环遍历参数组合
    for i = 1:num_combinations
        % 获取当前参数组合
        K = K_matrix(i, :);
        
        % 将 PID 控制器增益参数应用到 Simulink 模型中
%         set_param('shangtiao_22b/LFC/PID_Controller1', 'P', num2str(K(1)));
%         set_param('shangtiao_22b/LFC/PID_Controller1', 'I', num2str(K(2)));
        
%         set_param('shangtiao_22b/LFC_guolu/PID_Controller2', 'P', num2str(K(1)));
%         set_param('shangtiao_22b/LFC_guolu/PID_Controller2', 'I', num2str(K(2)));
        
%         set_param('shangtiao_22b/LFC_dianjielv/PID_Controller3', 'P', num2str(K(1)));
%         set_param('shangtiao_22b/LFC_dianjielv/PID_Controller3', 'I', num2str(K(2)));

        set_param('shangtiao_22b/LFC_dianjielv_guolu/PID_Controller4', 'P', num2str(K(1)));
        set_param('shangtiao_22b/LFC_dianjielv_guolu/PID_Controller4', 'I', num2str(K(2)));

        % 运行 Simulink 模型并获取输出
        simOut = sim('shangtiao_22b');


        itae_data = simOut.itae_dianjielv_guolu.data; % 频率itae数据

        % 计算性能指标 ITAE
        itae(i,1) = itae_data(end,1);
    end
end


